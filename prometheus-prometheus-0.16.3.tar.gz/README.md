# prometheus.prometheus
Ansible Collection for Prometheus

Documentation: https://prometheus-community.github.io/ansible/
