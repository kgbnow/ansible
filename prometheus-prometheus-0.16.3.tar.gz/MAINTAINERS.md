* Ben Kochie <superq@gmail.com> @SuperQ
* Garðar Arnarsson <github@gardar.net> @gardar
* Paweł Krupa <paulfantom@gmail.com> @paulfantom
